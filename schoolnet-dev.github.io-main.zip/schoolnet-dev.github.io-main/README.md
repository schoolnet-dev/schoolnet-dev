
![Logo](https://raw.githubusercontent.com/SchoolIzBoring/Unblocked-Websites/main/logo.png)


# Schoolnet

Schoolnet is an Open Source tool Website for school that includes games, proxies, tools, and more



## Demo
Soon! - Bradyn B


## Authors

- [@Bradyn Blackburn](https://schoolnet.github.io)


## License

[MIT](https://choosealicense.com/licenses/mit/)

