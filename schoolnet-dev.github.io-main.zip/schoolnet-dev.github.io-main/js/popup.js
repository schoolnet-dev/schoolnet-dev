function closePopup() {
  var popup = document.getElementById("popup");
  popup.style.display = "none";
}
